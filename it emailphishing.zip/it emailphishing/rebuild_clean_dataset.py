import os
import sys
import pandas as pd
import numpy as np

# Ensure src is importable
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "src"))
sys.path.append(ROOT)

from feature_extractor import (
    extract_engineered_features,
    extract_first_url,
)
from preprocessing.url_feature_extractor import extract_url_features


RAW_DATA_PATH = "data/raw/Phishing_Legitimate_full.csv"
SAVE_PATH = "data/clean_dataset.csv"

print(f"Loading RAW dataset: {RAW_DATA_PATH}")
df = pd.read_csv(RAW_DATA_PATH)

print("Loaded RAW dataset:", df.shape)

# ----------------------------------------------------------
# FIX SUBJECT/BODY MISSING IN RAW DATASET
# ----------------------------------------------------------
if "subject" not in df.columns:
    df["subject"] = ""

if "body" not in df.columns:
    if "TEXT" in df.columns:
        df["body"] = df["TEXT"]
    elif "email" in df.columns:
        df["body"] = df["email"]
    else:
        raise ValueError("Dataset needs either TEXT or email column to use as body.")

print("[OK] Subject and body columns added / confirmed.")

# ----------------------------------------------------------
# EMAIL ENGINEERED FEATURES
# ----------------------------------------------------------
df = extract_engineered_features(df)

print("[OK] Engineered email-body features added.")

# ----------------------------------------------------------
# URL FEATURES
# ----------------------------------------------------------
url_list = df.apply(lambda row: extract_first_url(str(row["body"])), axis=1)
url_features = []

for url in url_list:
    if url:
        url_features.append(extract_url_features(url))
    else:
        # fill zero values for all URL features
        url_features.append({key: 0 for key in extract_url_features("http://example.com")})

url_df = pd.DataFrame(url_features)
df = pd.concat([df, url_df], axis=1)

print("[OK] URL features added.")

# ----------------------------------------------------------
# CREATE TEXT COLUMN EXACTLY LIKE TRAINING
# ----------------------------------------------------------
df["TEXT"] = df.astype(str).agg(" ".join, axis=1)
print("[OK] TEXT column generated.")

# ----------------------------------------------------------
# SAVE CLEAN DATASET
# ----------------------------------------------------------
df.to_csv(SAVE_PATH, index=False)
print(f"\n🎉 CLEAN DATASET SAVED SUCCESSFULLY AT {SAVE_PATH}\n")
