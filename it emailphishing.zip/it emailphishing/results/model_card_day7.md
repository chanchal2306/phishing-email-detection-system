
# 📄 Final Model Card — Phishing Detection

### **Model:** Best Tuned Model (Random Forest Pipeline)
### **Date:** Day 7

---

## **1. Dataset Summary**
- Source: clean_dataset.csv  
- Samples: 9581  
- Features: 48 numeric phishing URL features  
- Target: CLASS_LABEL (0=Legit, 1=Phishing)

---

## **2. Train/Test Split**
- Train: 7664
- Test: 1917
- Split: 80/20 stratified

---

## **3. Final Performance (Test Set)**
- Accuracy:  1.0000
- Precision: 1.0000
- Recall:    1.0000
- F1 Score:  1.0000
- ROC AUC:   1.0000

---

## **4. Artifacts**
Saved in `../results/`:

- final_confusion_matrix.png
- final_roc_curve.png
- final_precision_recall_curve.png
- final_metrics.json

Model saved in:
- `../models/best_tuned_model.joblib`

---

## **5. Deployment Notes**
- Model expects *only numeric features*  
- Use same pipeline for preprocessing  
- Suitable for real-time phishing URL detection  
- Fast inference (Random Forest)

---
