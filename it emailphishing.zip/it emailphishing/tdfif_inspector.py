# tfidf_inspect.py
import joblib, sys
from pathlib import Path
import pandas as pd
import numpy as np
import re

ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT))

from src.preprocessing.url_feature_extractor import extract_url_features
from src.feature_extractor import extract_engineered_features, extract_first_url

MODEL = ROOT / "models" / "best_tuned_model.joblib"
pipeline = joblib.load(MODEL)

# build same feature DF used by app
def build_feature_dataframe(email_text: str, numeric_features):
    subject = ""
    body = email_text
    url = extract_first_url(email_text)
    if url:
        url_feats = extract_url_features(url)
    else:
        url_feats = {f: 0 for f in numeric_features}
    tmp = pd.DataFrame([{"subject": subject, "body": body}])
    tmp = extract_engineered_features(tmp)
    url_feats.update({
        "email_num_links": tmp["num_links"].iloc[0],
        "email_num_digits": tmp["num_digits"].iloc[0],
        "email_upper_ratio": tmp["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(tmp["subject_exclaim"].iloc[0]),
        "email_has_html": int(tmp["has_html"].iloc[0]),
        "email_suspicious_domain": int(tmp["suspicious_domain"].iloc[0]),
    })
    df = pd.DataFrame([url_feats])
    df["TEXT"] = email_text
    return df

# load numeric order
df_sample = pd.read_csv(ROOT / "data" / "clean_dataset.csv")
numeric_features = df_sample.drop(columns=["CLASS_LABEL"]).columns.tolist()

email = """Subject: Congratulations! You Won ₹10,00,000
Body:
Your email ID has been selected as the winner of our international lucky draw.
To claim the prize, reply with your full name, age, and bank account number.
This offer expires today!"""

print("=== EMAIL ===\n", email, "\n")

df_features = build_feature_dataframe(email, numeric_features)
print("Constructed TEXT:\n", df_features["TEXT"].iloc[0], "\n")

pre = pipeline.named_steps.get("preprocessor")
print("Preprocessor:", pre)

# Find the text transformer by matching columns argument == 'TEXT' (robust)
text_trans = None
text_cols = None
try:
    for name, trans, cols in pre.transformers_:
        # cols can be a string or list; make iterable
        if isinstance(cols, (list, tuple)):
            cols_list = list(cols)
        else:
            cols_list = [cols]
        if "TEXT" in cols_list:
            text_trans = trans
            text_cols = cols
            print(f"Found text transformer: {name} -> cols={cols}")
            break
except Exception as e:
    print("Could not iterate transformers_", e)

if text_trans is None:
    # fallback to named_transformers_
    nt = getattr(pre, "named_transformers_", {})
    for k, v in nt.items():
        if hasattr(v, "get_feature_names_out"):
            text_trans = v
            text_cols = k
            print("Found text transformer in named_transformers_ as:", k)
            break

if text_trans is None:
    print("Text transformer not found. Aborting token inspection.")
    sys.exit(1)

# Now transform TEXT using the TF-IDF transformer (it accepts list[str])
txt = [df_features["TEXT"].iloc[0]]
try:
    X_text = text_trans.transform(txt)
except Exception as e:
    print("text_trans.transform failed:", e)
    X_text = None

if X_text is None:
    print("Could not compute TF-IDF vector.")
    sys.exit(1)

# Get token names and non-zero weights
try:
    names = text_trans.get_feature_names_out()
except:
    try:
        names = np.array(sorted(text_trans.vocabulary_.keys()))
    except:
        names = None

print("\nTF-IDF vector shape:", X_text.shape)
if names is not None:
    row = X_text.toarray()[0]
    nz = np.where(row > 0)[0]
    print("Non-zero TF-IDF tokens count:", len(nz))
    for i in nz[:80]:
        print(f"{names[i]} -> {row[i]:.6f}")
else:
    print("Could not obtain TF-IDF feature names.")
