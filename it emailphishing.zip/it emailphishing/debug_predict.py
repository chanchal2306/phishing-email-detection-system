# debug_predict_fix.py
import joblib
import sys
import os
from pathlib import Path
import re
import numpy as np

# --- Email to test ---
email_text = """Subject: Congratulations! You Won ₹10,00,000
Body:
Your email ID has been selected as the winner of our international lucky draw.
To claim the prize, reply with your full name, age, and bank account number.
This offer expires today!"""

# --- Candidate model paths to try (in order) ---
cwd = Path.cwd()
here = Path(__file__).resolve().parent
candidates = [
    here / "models" / "best_tuned_model.joblib",               # ./models/best_tuned_model.joblib
    here / ".." / "models" / "best_tuned_model.joblib",       # ../models/best_tuned_model.joblib
    cwd / "models" / "best_tuned_model.joblib",               # workingdir/models/...
    cwd / ".." / "models" / "best_tuned_model.joblib",        # workingdir/../models/...
    here / "best_tuned_model.joblib",                         # next to script
    cwd / "best_tuned_model.joblib",
]

print("Current working directory:", cwd)
print("Script location (here):", here)
print("\nTrying candidate model paths:\n")
found = None
for p in candidates:
    p = p.resolve()
    exists = p.exists()
    print(f"{p} -> exists={exists}")
    if exists and found is None:
        found = p

# If not found, try to scan models dir and any joblib/pkl in project
if not found:
    scan = list(here.rglob("*.joblib")) + list(here.rglob("*.pkl"))
    if scan:
        print("\nFound these model files under the project:")
        for s in scan:
            print(" -", s.resolve())
        found = scan[0].resolve()
    else:
        print("\nNo .joblib or .pkl files found under project folder. You may have saved the model elsewhere.")
        print("Run in PowerShell from the project folder:\n  Get-ChildItem -Path . -Recurse -Include *.joblib,*.pkl")
        sys.exit(1)

print("\nUsing model file:", found)

# --- Load model safely ---
try:
    pipeline = joblib.load(found)
except Exception as e:
    print("Failed to load model with joblib:", e)
    sys.exit(1)

print("\nLoaded pipeline type:", type(pipeline))

# --- Print pipeline details if sklearn Pipeline ---
try:
    # print steps if pipeline object
    if hasattr(pipeline, "steps"):
        print("Pipeline steps:", [name for name, _ in pipeline.steps])
except Exception:
    pass

# --- Print model classes_ if present ---
clf = None
if hasattr(pipeline, "classes_"):
    print("pipeline.classes_:", pipeline.classes_)
else:
    # try to find classifier at end of pipeline
    try:
        last = pipeline.steps[-1][1]
        if hasattr(last, "classes_"):
            print("classifier.classes_:", last.classes_)
            clf = last
    except Exception:
        pass

# --- Preprocessing (simple normalization) ---
def preprocess(text):
    text = text.replace("\u2018","'").replace("\u2019","'").replace("\u201c",'"').replace("\u201d",'"')
    text = re.sub(r'\r\n|\r|\n', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

clean = preprocess(email_text)
print("\nPreprocessed text:")
print(clean)

# --- Predict ---
try:
    if hasattr(pipeline, "predict_proba"):
        probs = pipeline.predict_proba([clean])[0]
        pred = pipeline.predict([clean])[0]
        print("\npredict ->", pred)
        print("predict_proba ->", probs)
        # Determine class index for phishing if classes_ present
        classes = pipeline.classes_ if hasattr(pipeline, "classes_") else None
        if classes is not None:
            print("classes:", classes)
            # show phishing prob if classes include 1
            if 1 in classes:
                idx = list(classes).index(1)
                print("phishing probability (class==1):", probs[idx])
    else:
        pred = pipeline.predict([clean])[0]
        print("\npredict ->", pred)
except Exception as e:
    print("Prediction failed:", e)
    sys.exit(1)

# --- If vectorizer available, show suspicious tokens present ---
try:
    vec = None
    vect = None
    # if pipeline is sklearn Pipeline, find a vectorizer in steps
    if hasattr(pipeline, "named_steps"):
        for name, step in pipeline.named_steps.items():
            # common names: tfidf, vect, vectorizer
            if "tfidf" in name.lower() or "vector" in name.lower() or "count" in name.lower():
                vect = step
                break
    # attempt to detect vectorizer if standalone
    if not vect and hasattr(pipeline, "transform"):
        # pipeline might accept raw text; skip token listing
        vect = None

    if vect and hasattr(vect, "get_feature_names_out"):
        names = vect.get_feature_names_out()
        X = vect.transform([clean]).toarray()[0]
        suspicious_tokens = ["won","congrat","prize","bank","account","claim","reply","rupee","lottery","winner","₹"]
        print("\nSuspicious tokens present (token -> count):")
        for t in suspicious_tokens:
            # find tokens that contain t (partial match)
            matches = [n for n in names if t in n]
            for m in matches:
                idx = int(np.where(names == m)[0])
                if X[idx] > 0:
                    print(f" - '{m}' -> {X[idx]}")
    else:
        print("\nNo vectorizer available for token-check or unable to list token features.")
except Exception as e:
    print("Token presence check failed:", e)

print("\nDone.")
