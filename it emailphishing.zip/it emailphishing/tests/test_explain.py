import pytest
from src.explain import highlight_suspicious_tokens

def test_highlight_suspicious():
    txt = "Click here to verify your account"
    out = highlight_suspicious_tokens(txt)
    assert "<<Click>>" in out or "<<click>>" in out
