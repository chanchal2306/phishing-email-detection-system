import pytest
from src.robustness import homoglyph_attack, html_wrap_attack

def test_homoglyph_attack():
    text = "login"
    out = homoglyph_attack(text)
    assert out != text

def test_html_wrap():
    txt = "test email"
    wrapped = html_wrap_attack(txt)
    assert "<html>" in wrapped and "</html>" in wrapped


