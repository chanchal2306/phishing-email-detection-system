import pytest
from src.preprocessing.url_feature_extractor import extract_url_features

def test_url_feature_extractor():
    url = "http://example.com/login"
    feats = extract_url_features(url)

    assert isinstance(feats, dict)
    assert len(feats) == 48
    assert feats["UrlLength"] > 0
    assert "login" in url.lower()
