import os
import sys
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify
import joblib
import re
import json

# ----------------------------------------------------
# PATH FIX FOR src/
# ----------------------------------------------------
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(ROOT)

# ----------------------------------------------------
# IMPORT THE CORRECT MODULES (your actual folder structure!)
# ----------------------------------------------------
from src.feature_extractor import extract_engineered_features, extract_first_url
from src.preprocessing.url_feature_extractor import extract_url_features

# ----------------------------------------------------
# LOAD PIPELINE (PREPROCESSOR + MODEL)
# ----------------------------------------------------
MODEL_PATH = "../models/best_tuned_model.joblib"
pipeline = joblib.load(MODEL_PATH)

# ----------------------------------------------------
# LOAD CLEAN DATASET TO DISCOVER NUMERIC FEATURE ORDER
# ----------------------------------------------------
df_sample = pd.read_csv("../data/clean_dataset.csv")

# ❌ FIX: your CSV does NOT contain TEXT column → remove only CLASS_LABEL
NUMERIC_FEATURES = df_sample.drop(columns=["CLASS_LABEL"]).columns.tolist()


# ----------------------------------------------------
# BUILD FULL FEATURE SET FOR INFERENCE
# ----------------------------------------------------
def build_feature_dataframe(email_text: str):
    subject = ""
    body = email_text

    # 1) Extract URL
    url = extract_first_url(email_text)

    # 2) URL features
    if url:
        url_feats = extract_url_features(url)
    else:
        url_feats = {f: 0 for f in NUMERIC_FEATURES}

    # 3) Engineered text features
    tmp_df = pd.DataFrame([{"subject": subject, "body": body}])
    tmp_df = extract_engineered_features(tmp_df)

    url_feats.update({
        "email_num_links": tmp_df["num_links"].iloc[0],
        "email_num_digits": tmp_df["num_digits"].iloc[0],
        "email_upper_ratio": tmp_df["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(tmp_df["subject_exclaim"].iloc[0]),
        "email_has_html": int(tmp_df["has_html"].iloc[0]),
        "email_suspicious_domain": int(tmp_df["suspicious_domain"].iloc[0]),
    })

    df = pd.DataFrame([url_feats])

    # ---------------------------------------------
    # FIXED: TEXT must contain the real email text
    # ---------------------------------------------
    df["TEXT"] = email_text

    # final correct order
    final_cols = (
        NUMERIC_FEATURES +
        [
            "email_num_links", "email_num_digits", "email_upper_ratio",
            "email_subject_exclaim", "email_has_html", "email_suspicious_domain",
            "TEXT"
        ]
    )

    return df[final_cols]

# ----------------------------------------------------
# FLASK APP
# ----------------------------------------------------
app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True)
    email_text = None

    if data and "email" in data:
        email_text = data["email"]

    if email_text is None:
        email_text = request.form.get("email")

    if email_text is None:
        raw = request.data.decode("utf-8").strip()
        try:
            raw_json = json.loads(raw)
            email_text = raw_json.get("email", raw)
        except:
            email_text = raw

    if not email_text or email_text.strip() == "":
        return jsonify({"error": "No email text received"}), 400

    df_features = build_feature_dataframe(email_text)

    pred = pipeline.predict(df_features)[0]
    proba = pipeline.predict_proba(df_features)[0]

    classes = list(pipeline.classes_)
    phishing_prob = proba[classes.index(1)]
    legit_prob = proba[classes.index(0)]

    return jsonify({
        "prediction": int(pred),
        "prediction_label": "PHISHING" if pred >= 0.5 else "LEGITIMATE",
        "phishing_percentage": round(phishing_prob * 100, 2),
        "legitimate_percentage": round(legit_prob * 100, 2),
        "used_url": extract_first_url(email_text),
        "text": email_text
    })


@app.route("/result")
def result():
    return render_template("result.html")


if __name__ == "__main__":
    app.run(debug=True)
