import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score


# ============================================================
# 1. LOAD CLEANED DATASET
# ============================================================
DATA_PATH = "./data/clean_dataset.csv"

if not os.path.exists(DATA_PATH):
    raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")

df = pd.read_csv(DATA_PATH)

if "CLASS_LABEL" not in df.columns:
    raise ValueError("Dataset must contain CLASS_LABEL column.")


# ============================================================
# 2. REBUILD TEXT COLUMN EXACTLY LIKE TRAINING
# ============================================================
print("\n[INFO] Building TEXT column...")

df["TEXT"] = df.astype(str).agg(" ".join, axis=1)

# Identify numeric features
NUMERIC_FEATURES = df.drop(columns=["CLASS_LABEL", "TEXT"]).columns.tolist()

print(f"[INFO] Numeric feature count: {len(NUMERIC_FEATURES)}")
print(f"[INFO] TEXT column OK ✔")


# ============================================================
# 3. SPLIT DATA
# ============================================================
X = df[NUMERIC_FEATURES + ["TEXT"]]
y = df["CLASS_LABEL"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

print("[INFO] Dataset split completed.")


# ============================================================
# 4. BUILD FIXED PIPELINE (TFIDF + SCALER)
# ============================================================
print("[INFO] Building NEW, CORRECT pipeline...")

preprocessor = ColumnTransformer(
    transformers=[
        ("num", StandardScaler(), NUMERIC_FEATURES),
        ("text", TfidfVectorizer(
            stop_words="english",
            max_features=5000,
            ngram_range=(1, 2)
        ), "TEXT")
    ],
    remainder="drop"
)

pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", RandomForestClassifier(
        n_estimators=300,
        max_depth=25,
        random_state=42,
        n_jobs=-1
    ))
])

print("[INFO] Pipeline constructed ✔")


# ============================================================
# 5. TRAIN MODEL
# ============================================================
print("\n[INFO] Training model... this may take 15–30 seconds.")
pipeline.fit(X_train, y_train)

print("[INFO] Training completed ✔")


# ============================================================
# 6. EVALUATE MODEL
# ============================================================
print("\n[INFO] Evaluating model...")

y_pred = pipeline.predict(X_test)
acc = accuracy_score(y_test, y_pred)

print(f"\n🔥 NEW MODEL ACCURACY: {acc:.4f}\n")
print(classification_report(y_test, y_pred))


# ============================================================
# 7. SAVE MODEL
# ============================================================
MODEL_PATH = "./models/best_tuned_model.joblib"
os.makedirs("./models", exist_ok=True)

joblib.dump(pipeline, MODEL_PATH)

print(f"\n🎉 MODEL SAVED SUCCESSFULLY AT: {MODEL_PATH}")
print("Your Flask app will now produce correct phishing predictions ✔")


# ============================================================
# END
# ============================================================
