# deep_debug.py
import joblib, json, sys, os
from pathlib import Path
import pandas as pd
import numpy as np
import traceback

# adjust paths if needed
ROOT = Path(__file__).resolve().parent
MODELPATH = ROOT / "models" / "best_tuned_model.joblib"
DATA_CSV = ROOT / "data" / "clean_dataset.csv"

# import your feature building functions
sys.path.append(str(ROOT))
from src.preprocessing.url_feature_extractor import extract_url_features
from src.feature_extractor import extract_engineered_features, extract_first_url

# If you created build_feature_dataframe in app, import it, else we recreate minimal version:
def build_feature_dataframe(email_text: str, numeric_features):
    subject = ""
    body = email_text
    url = extract_first_url(email_text)

    if url:
        url_feats = extract_url_features(url)
    else:
        url_feats = {f: 0 for f in numeric_features}

    tmp = pd.DataFrame([{"subject": subject, "body": body}])
    tmp = extract_engineered_features(tmp)

    url_feats.update({
        "email_num_links": tmp["num_links"].iloc[0],
        "email_num_digits": tmp["num_digits"].iloc[0],
        "email_upper_ratio": tmp["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(tmp["subject_exclaim"].iloc[0]),
        "email_has_html": int(tmp["has_html"].iloc[0]),
        "email_suspicious_domain": int(tmp["suspicious_domain"].iloc[0]),
    })

    df = pd.DataFrame([url_feats])
    df["TEXT"] = df.astype(str).agg(" ".join, axis=1)
    return df

def main():
    try:
        print("Loading model:", MODELPATH)
        pipeline = joblib.load(MODELPATH)
        print("Loaded pipeline type:", type(pipeline))
        try:
            print("Pipeline steps:", list(pipeline.named_steps.keys()))
        except Exception:
            print("Pipeline has no named_steps")

        # numeric feature ordering
        df_sample = pd.read_csv(DATA_CSV)
        numeric_features = df_sample.drop(columns=["CLASS_LABEL"]).columns.tolist()
        print("Detected numeric feature count:", len(numeric_features))

        # Example suspicious email(s) to test
        test_emails = [
            """Subject: Congratulations! You Won ₹10,00,000
Body:
Your email ID has been selected as the winner of our international lucky draw.
To claim the prize, reply with your full name, age, and bank account number.
This offer expires today!"""
        ]

        for email in test_emails:
            print("\n\n=== TEST EMAIL ===")
            print(email)
            df_features = build_feature_dataframe(email, numeric_features)
            print("\nConstructed feature dataframe (first row):\n", df_features.iloc[0].to_dict())

            # show column order and dtypes
            print("\nColumns:", df_features.columns.tolist())
            print("dtypes:\n", df_features.dtypes)

            # transform shape
            try:
                X_trans = pipeline.transform(df_features)
                print("pipeline.transform() shape:", getattr(X_trans, "shape", str(type(X_trans))))
            except Exception as e:
                print("pipeline.transform() failed:", e)

            # predict and probabilities
            try:
                pred = pipeline.predict(df_features)[0]
                probs = pipeline.predict_proba(df_features)[0]
                classes = list(pipeline.classes_)
                print("predict:", pred)
                print("classes:", classes)
                print("probs:", probs)
                # phishing prob if class 1 exists
                if 1 in classes:
                    print("phishing_prob:", probs[classes.index(1)])
            except Exception as e:
                print("Predict failed:", e)
                traceback.print_exc()

            # optional: shap (if installed)
            try:
                import shap
                print("\nRunning SHAP (may take a moment)...")
                # get inner model (the classifier) if pipeline
                clf = pipeline.named_steps.get("model", pipeline)
                pre = pipeline.named_steps.get("preprocessor", None)
                if pre is None:
                    print("No preprocessor found for SHAP.")
                else:
                    # get numeric matrix preprocessed
                    Xnum = pre.transform(df_features)
                    expl = shap.TreeExplainer(clf)
                    shap_vals = expl.shap_values(Xnum)
                    print("SHAP computed (showing first 10 values):", shap_vals[1][0][:10] if isinstance(shap_vals, list) else shap_vals[0][:10])
            except Exception as e:
                print("SHAP not run (missing or failed):", e)

    except Exception as e:
        print("Fatal error:", e)
        traceback.print_exc()

if __name__ == "__main__":
    main()
