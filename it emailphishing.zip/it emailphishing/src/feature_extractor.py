import re
import numpy as np
import pandas as pd
from urllib.parse import urlparse
from src.preprocessing.text_utils import clean_text


def extract_engineered_features(df):
    df['clean_body'] = df['body'].apply(clean_text)
    
    df['has_html'] = df['body'].apply(lambda x: bool(re.search(r'<[^>]+>', x)))
    df['num_links'] = df['body'].apply(lambda x: len(re.findall(r'http[s]?://', x)))
    df['num_imgs'] = df['body'].apply(lambda x: len(re.findall(r'<img', x)))
    df['suspicious_domain'] = df['body'].apply(lambda x: bool(re.search(r'http[s]?://\d+\.\d+\.\d+\.\d+', x)))
    df['subject_exclaim'] = df['subject'].apply(lambda x: '!' in x if isinstance(x, str) else False)
    df['num_digits'] = df['body'].apply(lambda x: sum(c.isdigit() for c in x))
    df['upper_ratio'] = df['body'].apply(lambda x: sum(c.isupper() for c in x)/max(len(x),1))
    
    MONEY_RE = re.compile(r'[\u20B9$\€£]|(?:\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?)')
    CALL_TO_ACTION = ["reply", "click", "claim", "provide", "send", "verify", "update", "respond"]
    PERSONAL_INFO = ["bank account", "account number", "full name", "ssn", "passport", "card number"]

    df['has_money_symbol'] = df['body'].apply(lambda s: int(bool(MONEY_RE.search(str(s)))))
    df['money_amount_count'] = df['body'].apply(lambda s: len(MONEY_RE.findall(str(s))))
    df['call_to_action_count'] = df['body'].apply(lambda s: sum(str(s).lower().count(p) for p in CALL_TO_ACTION))
    df['personal_info_request'] = df['body'].apply(lambda s: int(any(p in str(s).lower() for p in PERSONAL_INFO)))
    df['num_sentences'] = df['body'].apply(lambda s: max(1, len([x for x in re.split(r'[.!?]+', str(s)) if x.strip()])))
    df['avg_sentence_len'] = df['body'].apply(lambda s: sum(len(sent.split()) for sent in re.split(r'[.!?]+', str(s)) if sent.strip()) / max(1, len([x for x in re.split(r'[.!?]+', str(s)) if x.strip()])))
    df['subject_win_word'] = df['subject'].apply(lambda x: int(isinstance(x, str) and any(w in x.lower() for w in ["won", "congrat", "prize", "winner"])))
# -----------------------

    return df

import re

def extract_first_url(text: str):
    """Extract the first URL found inside email text."""
    match = re.search(r"http[s]?://\S+", text)
    if match:
        return match.group(0)
    return None
