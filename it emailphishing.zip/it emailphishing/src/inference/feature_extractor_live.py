import pandas as pd
import numpy as np

# Correct imports based on YOUR actual folder structure
from src.preprocessing.url_feature_extractor import extract_url_features
from src.feature_extractor import extract_engineered_features, extract_first_url

# 48 URL-based numeric features used during training
NUMERIC_FEATURES = [
    'NumDots', 'SubdomainLevel', 'PathLevel', 'UrlLength', 'NumDash',
    'NumDashInHostname', 'AtSymbol', 'TildeSymbol', 'NumUnderscore',
    'NumPercent', 'NumQueryComponents', 'NumAmpersand', 'NumHash',
    'NumNumericChars', 'NoHttps', 'RandomString', 'IpAddress',
    'DomainInSubdomains', 'DomainInPaths', 'HttpsInHostname',
    'HostnameLength', 'PathLength', 'QueryLength', 'DoubleSlashInPath',
    'NumSensitiveWords', 'EmbeddedBrandName', 'PctExtHyperlinks',
    'PctExtResourceUrls', 'ExtFavicon', 'InsecureForms', 'RelativeFormAction',
    'ExtFormAction', 'AbnormalFormAction', 'PctNullSelfRedirectHyperlinks',
    'FrequentDomainNameMismatch', 'FakeLinkInStatusBar', 'RightClickDisabled',
    'PopUpWindow', 'SubmitInfoToEmail', 'IframeOrFrame', 'MissingTitle',
    'ImagesOnlyInForm', 'SubdomainLevelRT', 'UrlLengthRT',
    'PctExtResourceUrlsRT', 'AbnormalExtFormActionR',
    'ExtMetaScriptLinkRT', 'PctExtNullSelfRedirectHyperlinksRT'
]


def build_feature_dataframe(subject, body):
    """
    Build the final DataFrame for inference, containing:
    - 48 URL numeric features
    - 6 engineered email text features
    - TEXT column for NLP vectorizer
    """

    # ---------------------------------------------------------
    # 1) Merge subject + body → find first URL
    # ---------------------------------------------------------
    email_text = f"{subject} {body}"
    url = extract_first_url(email_text)

    # ---------------------------------------------------------
    # 2) Extract URL features (48)
    # ---------------------------------------------------------
    if url:
        url_features = extract_url_features(url)
    else:
        # No URL detected → Zero vector for all URL features
        url_features = {f: 0 for f in NUMERIC_FEATURES}

    # ---------------------------------------------------------
    # 3) Extract engineered text features from subject + body
    # ---------------------------------------------------------
    temp = pd.DataFrame([{"subject": subject, "body": body}])
    temp = extract_engineered_features(temp)

    url_features.update({
        "email_num_links": temp["num_links"].iloc[0],
        "email_num_digits": temp["num_digits"].iloc[0],
        "email_upper_ratio": temp["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(temp["subject_exclaim"].iloc[0]),
        "email_has_html": int(temp["has_html"].iloc[0]),
        "email_suspicious_domain": int(temp["suspicious_domain"].iloc[0]),
    })

    # ---------------------------------------------------------
    # 4) Build TEXT column exactly like in training
    # ---------------------------------------------------------
    df = pd.DataFrame([url_features])
    df["subject"] = subject
    df["body"] = body

    # EXACT training replication: full row → str → join
    df["TEXT"] = df.astype(str).agg(" ".join, axis=1)

    # ---------------------------------------------------------
    # 5) Final column ordering
    # ---------------------------------------------------------
    final_cols = (
        NUMERIC_FEATURES +
        [
            "email_num_links", "email_num_digits", "email_upper_ratio",
            "email_subject_exclaim", "email_has_html", "email_suspicious_domain",
            "TEXT"
        ]
    )

    return df[final_cols]
