# =============================
# explain.py
# Explainability module for Phishing ML Project
# =============================

import re
import numpy as np
import pandas as pd
import shap
from src.preprocessing.url_feature_extractor import extract_url_features


# ===============================================================
# 1. Highlight Suspicious Tokens
# ===============================================================

SUSPICIOUS_KEYWORDS = [
    "verify", "click", "login", "update", "password",
    "bank", "urgent", "suspended", "invoice",
    "limited", "confirm", "reset", "account"
]

def highlight_suspicious_tokens(text: str) -> str:
    """Highlight suspicious phishing-trigger words inside email text."""
    words = text.split()
    highlighted = []

    for w in words:
        clean = re.sub(r"[^\w]", "", w).lower()
        if clean in SUSPICIOUS_KEYWORDS:
            highlighted.append(f"<<{w}>>")
        else:
            highlighted.append(w)

    return " ".join(highlighted)



# ===============================================================
# 2. Explain a single NUMERIC row using SHAP
# ===============================================================

def explain_row_numeric(model_pipeline, row, numeric_features, top_n=6):
    """Explain a single row of numeric features."""

    preprocessor = model_pipeline.named_steps["preprocessor"]
    rf_model = model_pipeline.named_steps["model"]

    row_df = row.to_frame().T
    X_num = preprocessor.named_transformers_["num"].transform(row_df)

    explainer = shap.TreeExplainer(rf_model)
    shap_vals = explainer.shap_values(X_num)

    # ---- FIX 1: handle 1-output or 2-output SHAP models ----
    if isinstance(shap_vals, list):
        if len(shap_vals) == 2:
            svals = shap_vals[1][0]
        else:
            svals = shap_vals[0][0]
    else:
        svals = shap_vals[0]

    # ---- FIX 2: force into 1-D vector ----
    svals = np.ravel(svals)

    # ---- FIX 3: ensure SHAP vector length matches feature count ----
    if len(svals) != len(numeric_features):
        min_len = min(len(svals), len(numeric_features))
        svals = svals[:min_len]
        numeric_features = numeric_features[:min_len]

    # Build contribution table
    contrib = (
        pd.DataFrame({
            "feature": numeric_features,
            "shap_value": svals
        })
        .assign(abs_shap=lambda d: d["shap_value"].abs())
        .sort_values("abs_shap", ascending=False)
    )

    pred = model_pipeline.predict(row_df)[0]
    proba = model_pipeline.predict_proba(row_df)[0][1]

    return {
        "prediction": int(pred),
        "probability": float(proba),
        "top_contributors": contrib.head(top_n)[["feature", "shap_value"]].to_dict(orient="records")
    }

# ===============================================================
# 3. Minimal DEMO numeric extraction (used in Flask UI)
# ===============================================================

def prepare_numeric_features_from_email(email_text: str, numeric_features):
    """
    Extract URL from email text and compute full numeric URL features.
    """

    # Find URL inside the email (simple pattern)
    match = re.search(r"http[s]?://\S+", email_text)
    if not match:
        # No URL found → return zero vector
        return {f: 0 for f in numeric_features}

    url = match.group(0)

    # Extract full 48-feature vector
    raw_feats = extract_url_features(url)

    # Ensure order matches training dataset
    return {f: raw_feats.get(f, 0) for f in numeric_features}


# ===============================================================
# 4. Explain Raw Email (UI + SHAP demo)
# ===============================================================

def explain_email_text(model_pipeline, email_text: str, numeric_features):

    feat = prepare_numeric_features_from_email(email_text, numeric_features)

    df_temp = pd.DataFrame([feat], columns=numeric_features)

    explanation = explain_row_numeric(
        model_pipeline,
        df_temp.iloc[0],
        numeric_features
    )

    explanation["highlighted_text"] = highlight_suspicious_tokens(email_text)

    return explanation
