"""
src/preprocessing/text_cleaning.py

Provides functions to clean email text/body/subject.
- removes HTML (keeps plain text)
- extracts and optionally removes links
- lowercases, strips punctuation (configurable)
- optional stopword removal
- safe handling of None / non-string inputs
"""

import re
from bs4 import BeautifulSoup
import nltk
from nltk.corpus import stopwords
from typing import Tuple, List, Optional

# Ensure NLTK stopwords are available (run once in your env)
try:
    STOPWORDS = set(stopwords.words("english"))
except LookupError:
    nltk.download("stopwords")
    STOPWORDS = set(stopwords.words("english"))

URL_REGEX = re.compile(r'(https?://[^\s"<]+|www\.[^\s"<]+)', re.IGNORECASE)
HTML_TAG_REGEX = re.compile(r'<[^>]+>')
PUNCT_REGEX = re.compile(r'[^\w\s]')  # anything that's not letter/number/underscore/space

def _safe_text(x) -> str:
    if x is None:
        return ""
    if not isinstance(x, str):
        try:
            return str(x)
        except Exception:
            return ""
    return x

def extract_links(text: str) -> List[str]:
    """Return list of URLs found in text."""
    text = _safe_text(text)
    return URL_REGEX.findall(text)

def remove_html(text: str) -> str:
    """Strip HTML tags and return plain text."""
    text = _safe_text(text)
    # Use BeautifulSoup to handle entities and scripts gracefully
    soup = BeautifulSoup(text, "lxml")
    # remove script/style elements just in case
    for script in soup(["script", "style"]):
        script.decompose()
    return soup.get_text(separator=" ")

def clean_text(text: str,
               remove_urls: bool = True,
               remove_punct: bool = True,
               lowercase: bool = True,
               remove_stopwords: bool = False) -> str:
    """
    Clean input text and return cleaned string.

    Args:
        text: raw text or HTML
        remove_urls: strip urls (default True)
        remove_punct: remove punctuation characters (default True)
        lowercase: lowercase text (default True)
        remove_stopwords: remove NLTK stopwords (default False -- optional)

    Returns:
        cleaned text string
    """
    text = _safe_text(text)
    # Remove HTML first
    text = remove_html(text)

    # Optionally extract & remove URLs
    if remove_urls:
        text = URL_REGEX.sub(" ", text)

    # Normalize whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    if lowercase:
        text = text.lower()

    if remove_punct:
        # keep underscores and alphanumerics and spaces
        text = PUNCT_REGEX.sub(' ', text)
        text = re.sub(r'\s+', ' ', text).strip()

    if remove_stopwords:
        tokens = [t for t in text.split() if t not in STOPWORDS]
        text = " ".join(tokens)

    return text

def clean_and_extract(text: str,
                      remove_urls: bool = True,
                      remove_punct: bool = True,
                      lowercase: bool = True,
                      remove_stopwords: bool = False
                      ) -> Tuple[str, List[str]]:
    """
    Return tuple (cleaned_text, list_of_extracted_urls)
    Useful when you want to keep features like num_links while removing them from cleaned text.
    """
    raw = _safe_text(text)
    links = extract_links(raw)
    cleaned = clean_text(raw, remove_urls=remove_urls, remove_punct=remove_punct,
                         lowercase=lowercase, remove_stopwords=remove_stopwords)
    return cleaned, links
