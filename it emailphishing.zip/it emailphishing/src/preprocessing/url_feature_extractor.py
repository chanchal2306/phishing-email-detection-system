import re
import tldextract

# Sensitive keywords
SENSITIVE_WORDS = [
    "secure", "account", "login", "signin", "bank", "support",
    "confirm", "update", "verification", "authenticate",
    "password", "billing", "invoice"
]

def count_sensitive_words(url):
    url_lower = url.lower()
    return sum(1 for w in SENSITIVE_WORDS if w in url_lower)

def extract_url_features(url: str) -> dict:
    url = url.strip()
    url_lower = url.lower()

    # Extract domain
    ext = tldextract.extract(url)
    domain = ext.domain or ""
    subdomain = ext.subdomain or ""

    # Base numeric features
    features = {
        "NumDots": url.count("."),
        "SubdomainLevel": len(subdomain.split(".")) if subdomain else 0,
        "PathLevel": url.count("/") - 2,
        "UrlLength": len(url),
        "NumDash": url.count("-"),
        "NumDashInHostname": ext.domain.count("-") if ext.domain else 0,
        "AtSymbol": 1 if "@" in url else 0,
        "TildeSymbol": url.count("~"),
        "NumUnderscore": url.count("_"),
        "NumPercent": url.count("%"),
        "NumQueryComponents": len(url.split("&")) if "&" in url else 0,
        "NumAmpersand": url.count("&"),
        "NumHash": url.count("#"),
        "NumNumericChars": sum(ch.isdigit() for ch in url),
        "NoHttps": 0 if url_lower.startswith("https") else 1,
        "RandomString": 1 if re.search(r"[a-zA-Z0-9]{15,}", domain) else 0,
        "IpAddress": 1 if re.search(r"\d+\.\d+\.\d+\.\d+", url) else 0,
        "DomainInSubdomains": 1 if domain in subdomain else 0,
        "DomainInPaths": 1 if domain in url_lower.split("/") else 0,
        "HttpsInHostname": 1 if "https" in domain else 0,
        "HostnameLength": len(ext.domain or ""),
        "PathLength": len(url.split("//")[-1].split("/",1)[-1]),
        "QueryLength": len(url.split("?")[-1]) if "?" in url else 0,
        "DoubleSlashInPath": url.count("//"),
        "NumSensitiveWords": count_sensitive_words(url),
        "EmbeddedBrandName": 1 if domain in url_lower else 0,
        "PctExtHyperlinks": 0,
        "PctExtResourceUrls": 0,
        "ExtFavicon": 0,
        "InsecureForms": 0,
        "RelativeFormAction": 0,
        "ExtFormAction": 0,
        "AbnormalFormAction": 0,
        "PctNullSelfRedirectHyperlinks": 0,
        "FrequentDomainNameMismatch": 0,
        "FakeLinkInStatusBar": 0,
        "RightClickDisabled": 0,
        "PopUpWindow": 0,
        "SubmitInfoToEmail": 1 if "mail(" in url_lower or "mailto:" in url_lower else 0,
        "IframeOrFrame": 0,
        "MissingTitle": 0,
        "ImagesOnlyInForm": 0,
        "SubdomainLevelRT": len(subdomain.split(".")) if subdomain else 0,
        "UrlLengthRT": len(url),
        "PctExtResourceUrlsRT": 0,
        "AbnormalExtFormActionR": 0,
        "ExtMetaScriptLinkRT": 0,
        "PctExtNullSelfRedirectHyperlinksRT": 0
    }

    return features
