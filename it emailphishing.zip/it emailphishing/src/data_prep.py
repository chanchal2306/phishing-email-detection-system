import os
import glob
import re
import pandas as pd
from email import policy
from email.parser import BytesParser
from bs4 import BeautifulSoup
import tldextract
from tqdm import tqdm

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
RAW_DIR = os.path.abspath(RAW_DIR)

def parse_eml(path):
    """Return dict with id, subject, body (text/html combined)"""
    with open(path, 'rb') as f:
        msg = BytesParser(policy=policy.default).parse(f)
    subject = msg.get('subject', "")
    # walk and get payload text/html or text/plain
    parts = []
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            if ctype == 'text/plain':
                parts.append(part.get_content())
            elif ctype == 'text/html':
                html = part.get_content()
                # strip tags
                soup = BeautifulSoup(html, 'html.parser')
                parts.append(soup.get_text(separator=' '))
    else:
        ctype = msg.get_content_type()
        if ctype == 'text/plain':
            parts.append(msg.get_content())
        elif ctype == 'text/html':
            soup = BeautifulSoup(msg.get_content(), 'html.parser')
            parts.append(soup.get_text(separator=' '))
    body = "\n".join([p for p in parts if p])
    return {"id": os.path.basename(path), "subject": subject or "", "body": body or ""}

def extract_urls(text):
    # simple regex to find urls
    url_re = r'(https?://[^\s\'"<>]+)'
    return re.findall(url_re, text or "")

def domain_from_url(url):
    ext = tldextract.extract(url)
    if ext.domain:
        return ".".join([ext.domain, ext.suffix]) if ext.suffix else ext.domain
    return url

def try_map_label(val):
    """Map common label text to 0/1, otherwise return None"""
    if pd.isna(val):
        return None
    v = str(val).strip().lower()
    if v in ("phishing", "phish", "malicious", "1", "true", "yes"):
        return 1
    if v in ("legitimate", "benign", "ham", "0", "false", "no"):
        return 0
    return None

def read_csv_generic(path):
    df = pd.read_csv(path, low_memory=False)
    # try to infer label column
    label_col = None
    for candidate in ['label','class','target','CLASS_LABEL','Result','is_phishing','type']:
        if candidate in df.columns:
            label_col = candidate
            break
    # find columns for subject/body
    subj = None
    body = None
    for candidate in ['subject','title','email_subject','Subject']:
        if candidate in df.columns:
            subj = candidate; break
    for candidate in ['body','content','email_body','text','message']:
        if candidate in df.columns:
            body = candidate; break

    rows = []
    for idx, row in df.iterrows():
        rid = row.get('id', f"{os.path.basename(path)}_{idx}")
        subject = row.get(subj, "") if subj else ""
        bodytext = row.get(body, "") if body else ""
        lbl = try_map_label(row.get(label_col)) if label_col else try_map_label(row.get('CLASS_LABEL'))
        rows.append({"id": rid, "subject": subject, "body": bodytext, "label": lbl})
    return pd.DataFrame(rows)

def unify(raw_dir=RAW_DIR):
    all_rows = []
    # process eml
    eml_files = glob.glob(os.path.join(raw_dir, "**", "*.eml"), recursive=True)
    for p in tqdm(eml_files, desc="Reading .eml"):
        d = parse_eml(p)
        d['label'] = None
        all_rows.append(d)

    # process csv / txt
    csv_files = glob.glob(os.path.join(raw_dir, "**", "*.csv"), recursive=True)
    for p in tqdm(csv_files, desc="Reading .csv"):
        try:
            df = read_csv_generic(p)
            all_rows.extend(df.to_dict('records'))
        except Exception as e:
            print("Failed reading", p, e)

    txt_files = glob.glob(os.path.join(raw_dir, "**", "*.txt"), recursive=True)
    for p in tqdm(txt_files, desc="Reading .txt"):
        try:
            with open(p, 'r', encoding='utf8', errors='ignore') as f:
                content = f.read()
            # treat entire file as one body entry
            all_rows.append({"id": os.path.basename(p), "subject": "", "body": content, "label": None})
        except Exception as e:
            print("Failed", p, e)

    df_all = pd.DataFrame(all_rows, columns=["id","subject","body","label"])
    # fill label using CLASS_LABEL if present in mixed csvs
    # ensure label is 0/1 where possible
    df_all['label'] = df_all['label'].apply(lambda x: try_map_label(x) if x is not None else None)
    return df_all

if __name__ == "__main__":
    df = unify()
    out_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
    out_path = os.path.join(out_dir, "dataset.csv")
    os.makedirs(out_dir, exist_ok=True)
    df.to_csv(out_path, index=False)
    print("Saved unified dataset to", out_path)
