import re
import numpy as np
import pandas as pd
from src.preprocessing.url_feature_extractor import extract_url_features

# =============================
# 1. Obfuscation Attacks
# =============================

HOMOGLYPH_MAP = {
    "a": "а",  # Cyrillic
    "e": "е",  # Cyrillic
    "i": "і",  # Ukrainian
    "o": "ο",  # Greek
    "p": "р",  # Cyrillic
    "c": "с",  # Cyrillic
}

def homoglyph_attack(text):
    """Replace characters with look-alike unicode to fool filters."""
    out = ""
    for ch in text:
        out += HOMOGLYPH_MAP.get(ch.lower(), ch)
    return out


def remove_spaces_attack(text):
    """Simple obfuscation by removing spaces."""
    return text.replace(" ", "")


def html_wrap_attack(text):
    """Make email appear as HTML-only."""
    return f"<html><body><p>{text}</p></body></html>"


def random_insertion(text, n=5):
    """Insert random characters in text."""
    junk = ["$$$", "###", "@@@", "!!!"]
    for _ in range(n):
        text += np.random.choice(junk)
    return text


# =============================
# 2. Robustness Test Function
# =============================

def test_model_robustness(pipeline, email_text, numeric_features):
    """
    Feed several adversarial versions of the email to the model.
    Returns predictions for each version.
    """

    from src.explain import explain_email_text  # delayed import

    tests = {
        "original": email_text,
        "homoglyph": homoglyph_attack(email_text),
        "no_spaces": remove_spaces_attack(email_text),
        "html_wrapped": html_wrap_attack(email_text),
        "random_insert": random_insertion(email_text)
    }

    results = {}

    for name, txt in tests.items():
        try:
            exp = explain_email_text(pipeline, txt, numeric_features)
            results[name] = {
                "prediction": exp["prediction"],
                "probability": exp["probability"]
            }
        except Exception as e:
            results[name] = {"error": str(e)}

    return results
