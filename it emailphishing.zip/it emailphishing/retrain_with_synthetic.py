"""
retrain_with_synthetic.py

Generates a synthetic email dataset (phishing + legitimate),
computes URL + engineered email features using your project's
extractors, trains a corrected TF-IDF + numeric pipeline,
and saves the model to ./models/best_tuned_model.joblib.

Usage:
    python retrain_with_synthetic.py
"""

import os
import random
import string
import joblib
import numpy as np
import pandas as pd
from pathlib import Path

# sklearn
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score

# make sure src is importable
ROOT = Path(__file__).resolve().parent
import sys
sys.path.append(str(ROOT))

# Import your existing functions (must exist)
from src.preprocessing.url_feature_extractor import extract_url_features
from src.feature_extractor import extract_engineered_features, extract_first_url

# ---------- Configuration ----------
SYNTHETIC_PHISH = 2500   # number of phishing samples to create
SYNTHETIC_LEGIT = 2500   # number of legit samples to create
RANDOM_SEED = 42
MODEL_OUT = ROOT / "models" / "best_tuned_model.joblib"

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

# Numeric feature names expected by your pipeline (taken from your dataset)
NUMERIC_FEATURES = [
    'NumDots', 'SubdomainLevel', 'PathLevel', 'UrlLength', 'NumDash',
    'NumDashInHostname', 'AtSymbol', 'TildeSymbol', 'NumUnderscore',
    'NumPercent', 'NumQueryComponents', 'NumAmpersand', 'NumHash',
    'NumNumericChars', 'NoHttps', 'RandomString', 'IpAddress',
    'DomainInSubdomains', 'DomainInPaths', 'HttpsInHostname',
    'HostnameLength', 'PathLength', 'QueryLength', 'DoubleSlashInPath',
    'NumSensitiveWords', 'EmbeddedBrandName', 'PctExtHyperlinks',
    'PctExtResourceUrls', 'ExtFavicon', 'InsecureForms', 'RelativeFormAction',
    'ExtFormAction', 'AbnormalFormAction', 'PctNullSelfRedirectHyperlinks',
    'FrequentDomainNameMismatch', 'FakeLinkInStatusBar', 'RightClickDisabled',
    'PopUpWindow', 'SubmitInfoToEmail', 'IframeOrFrame', 'MissingTitle',
    'ImagesOnlyInForm', 'SubdomainLevelRT', 'UrlLengthRT', 'PctExtResourceUrlsRT',
    'AbnormalExtFormActionR', 'ExtMetaScriptLinkRT', 'PctExtNullSelfRedirectHyperlinksRT'
]

# ---------- Helper: URL generator ----------
def make_random_domain(with_brand=False):
    # common domains used for legit vs phishing
    brands = ["banksecure", "onlinepay", "mybank", "securelogin", "verifyit", "paypal-support"]
    free = ["gmail.com", "yahoo.com", "outlook.com"]
    if with_brand and random.random() < 0.7:
        d = random.choice(brands) + random.choice([".com", ".net", ".org"])
    else:
        d = random.choice(free)
    return d

def make_random_path():
    parts = []
    for _ in range(random.randint(0,4)):
        parts.append(''.join(random.choices(string.ascii_lowercase + string.digits, k=random.randint(3,10))))
    return "/".join(parts)

def make_url(phishing_like=False):
    # construct a URL; phishing_like True increases chance of weird patterns
    scheme = "http" if (phishing_like and random.random() < 0.3) else "https"
    if phishing_like and random.random() < 0.5:
        # sometimes include IP address
        ip = ".".join(str(random.randint(1,255)) for _ in range(4))
        host = ip
    else:
        host = make_random_domain(with_brand=(phishing_like and random.random()<0.8))
    path = make_random_path()
    q = ""
    if random.random() < 0.4:
        q = "?ref=" + ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    url = f"{scheme}://{host}"
    if path:
        url += "/" + path
    url += q
    return url

# ---------- Synthetic templates ----------
PHISHING_TEMPLATES = [
    # Lottery / prize
    ("Subject: Congratulations! You Won {amt}",
     "Body:\nYour email ID has been selected as the winner of our international lucky draw. To claim the prize of {amt}, reply with your full name, age, and bank account number. This offer expires today!"),
    # Credential stealing
    ("Subject: Action required: Verify your account",
     "Body:\nWe detected suspicious activity on your account. Please verify your identity now by visiting {url} and reset your password."),
    # Bank alert
    ("Subject: Important: Unusual activity in your account",
     "Body:\nWe noticed an unauthorized payment. If this wasn't you, please login to {url} and confirm your transactions."),
    # Invoice scam
    ("Subject: Invoice {inv} attached",
     "Body:\nPlease review the attached invoice and pay immediately. Open at {url} to view the invoice."),
]

LEGIT_TEMPLATES = [
    ("Subject: Your order #{order} has shipped",
     "Body:\nThanks for your purchase. Track your shipment at {url} or in your account."),
    ("Subject: Weekly newsletter — updates from our team",
     "Body:\nThis week's stories, product tips, and community updates. No action required."),
    ("Subject: Your receipt from {store}",
     "Body:\nThank you for shopping. Your receipt is available in your account."),
    ("Subject: Appointment confirmation",
     "Body:\nYour appointment is confirmed for {date}. If you need to reschedule, visit {url}."),
]

# ---------- Build synthetic dataset ----------
def gen_phishing_sample():
    tpl = random.choice(PHISHING_TEMPLATES)
    subject_tpl, body_tpl = tpl
    # amount for lottery
    amt = f"₹{random.randint(10000,1000000):,}".replace(",",",")
    inv = ''.join(random.choices(string.digits, k=6))
    url = make_url(phishing_like=True) if random.random() < 0.8 else ""
    subject = subject_tpl.format(amt=amt, inv=inv, url=url)
    body = body_tpl.format(amt=amt, inv=inv, url=url)
    # sometimes include extra social-engineering phrases
    if random.random() < 0.6:
        body += "\nPlease act now, this is urgent!"
    # include bank/account request sometimes
    if random.random() < 0.4:
        body += "\nProvide your bank account number to claim the funds."
    return subject, body, url

def gen_legit_sample():
    tpl = random.choice(LEGIT_TEMPLATES)
    subject_tpl, body_tpl = tpl
    order = random.randint(10000,99999)
    store = random.choice(["ShopEasy", "OfficeSupplies", "SuperMart"])
    url = make_url(phishing_like=False) if random.random() < 0.6 else ""
    date = f"{random.randint(10,28)}/{random.randint(1,12)}/2025"
    subject = subject_tpl.format(order=order, store=store, date=date, url=url)
    body = body_tpl.format(order=order, store=store, date=date, url=url)
    if random.random() < 0.3:
        body += "\nTrack your order at " + (url or "https://"+make_random_domain())
    return subject, body, url

# ---------- Convert samples into feature DataFrame ----------
def build_feature_row_from_email(subject, body):
    email_text = subject + "\n" + body
    # extract first URL
    url = extract_first_url(email_text)
    # URL numeric features (47)
    if url:
        url_feats = extract_url_features(url)
    else:
        # zero out keys using extract_url_features on a dummy URL to ensure same keys
        url_feats = {k: 0 for k in extract_url_features("https://example.com").keys()}
    # engineered email features
    tmp = pd.DataFrame([{"subject": subject, "body": body}])
    tmp = extract_engineered_features(tmp)
    url_feats.update({
        "email_num_links": tmp["num_links"].iloc[0],
        "email_num_digits": tmp["num_digits"].iloc[0],
        "email_upper_ratio": tmp["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(tmp["subject_exclaim"].iloc[0]),
        "email_has_html": int(tmp["has_html"].iloc[0]),
        "email_suspicious_domain": int(tmp["suspicious_domain"].iloc[0]),
    })
    # build TEXT as raw email text (NOT numeric row)
    row = url_feats.copy()
    row["TEXT"] = email_text
    return row

# ---------- Generate dataset ----------
def generate_dataset(n_phish, n_legit):
    rows = []
    labels = []
    for _ in range(n_phish):
        subj, body, _ = gen_phishing_sample()
        rows.append(build_feature_row_from_email(subj, body))
        labels.append(1)
    for _ in range(n_legit):
        subj, body, _ = gen_legit_sample()
        rows.append(build_feature_row_from_email(subj, body))
        labels.append(0)
    df = pd.DataFrame(rows)
    df["CLASS_LABEL"] = labels
    # ensure column order: numeric features (existing keys) + engineered + TEXT + CLASS_LABEL
    # compute numeric_keys from extract_url_features to ensure consistent ordering
    sample_keys = [k for k in extract_url_features("https://example.com").keys()]
    engineered = ["email_num_links", "email_num_digits", "email_upper_ratio",
                  "email_subject_exclaim", "email_has_html", "email_suspicious_domain"]
    final_cols = sample_keys + engineered + ["TEXT", "CLASS_LABEL"]
    # Some keys may already be present — ensure any additional keys are included
    for c in final_cols:
        if c not in df.columns:
            df[c] = 0
    df = df[final_cols]
    return df

# ---------- Train pipeline ----------
def train_and_save(df):
    print("[info] dataset shape:", df.shape)
    # numeric features are all columns except TEXT and CLASS_LABEL
    numeric_cols = [c for c in df.columns if c not in ("TEXT", "CLASS_LABEL")]
    X = df[numeric_cols + ["TEXT"]]
    y = df["CLASS_LABEL"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=RANDOM_SEED, stratify=y)
    # ColumnTransformer: scale numeric, tfidf on TEXT
    pre = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), numeric_cols),
            ("text", TfidfVectorizer(stop_words="english", max_features=5000, ngram_range=(1,2)), "TEXT")
        ],
        remainder="drop"
    )
    pipeline = Pipeline([
        ("preprocessor", pre),
        ("model", RandomForestClassifier(n_estimators=300, max_depth=25, random_state=RANDOM_SEED, n_jobs=-1))
    ])
    print("[info] training pipeline...")
    pipeline.fit(X_train, y_train)
    print("[info] evaluating...")
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, list(pipeline.classes_).index(1)]
    print("Accuracy:", accuracy_score(y_test, y_pred))
    print(classification_report(y_test, y_pred))
    # save model
    os.makedirs(MODEL_OUT.parent, exist_ok=True)
    joblib.dump(pipeline, MODEL_OUT)
    print("[info] saved model to", MODEL_OUT)
    return pipeline

# ---------- Main ----------
if __name__ == "__main__":
    print("Generating synthetic dataset...")
    df_synth = generate_dataset(SYNTHETIC_PHISH, SYNTHETIC_LEGIT)
    print("Sample rows:")
    print(df_synth.head(2).T[:30])
    # Save dataset for inspection/training reproducibility
    df_synth.to_csv(ROOT / "data" / "clean_dataset_synthetic.csv", index=False)
    print("[info] saved synthetic clean dataset to data/clean_dataset_synthetic.csv")
    model = train_and_save(df_synth)
    print("Done.")
