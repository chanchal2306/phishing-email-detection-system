# token_debug.py
import joblib, sys, json
from pathlib import Path
import pandas as pd
import numpy as np
import re

ROOT = Path(__file__).resolve().parent
sys.path.append(str(ROOT))

from src.preprocessing.url_feature_extractor import extract_url_features
from src.feature_extractor import extract_engineered_features, extract_first_url

# load pipeline
MODEL = ROOT / "models" / "best_tuned_model.joblib"
pipeline = joblib.load(MODEL)

# build feature dataframe helper (same as in app)
def build_feature_dataframe(email_text: str, numeric_features):
    subject = ""
    body = email_text
    url = extract_first_url(email_text)
    if url:
        url_feats = extract_url_features(url)
    else:
        url_feats = {f: 0 for f in numeric_features}
    tmp = pd.DataFrame([{"subject": subject, "body": body}])
    tmp = extract_engineered_features(tmp)
    url_feats.update({
        "email_num_links": tmp["num_links"].iloc[0],
        "email_num_digits": tmp["num_digits"].iloc[0],
        "email_upper_ratio": tmp["upper_ratio"].iloc[0],
        "email_subject_exclaim": int(tmp["subject_exclaim"].iloc[0]),
        "email_has_html": int(tmp["has_html"].iloc[0]),
        "email_suspicious_domain": int(tmp["suspicious_domain"].iloc[0]),
    })
    df = pd.DataFrame([url_feats])
    # *** CORRECT: TEXT is actual email content
    df["TEXT"] = email_text
    return df

# load numeric feature order
df_sample = pd.read_csv(ROOT / "data" / "clean_dataset.csv")
numeric_features = df_sample.drop(columns=["CLASS_LABEL"]).columns.tolist()

# ====== Test email ======
email = """Subject: Congratulations! You Won ₹10,00,000
Body:
Your email ID has been selected as the winner of our international lucky draw.
To claim the prize, reply with your full name, age, and bank account number.
This offer expires today!"""

print("=== RAW EMAIL ===")
print(email)
print("")

df_features = build_feature_dataframe(email, numeric_features)
print("=== Constructed feature row (sample) ===")
print(df_features.iloc[0].to_dict())
print("")

# Inspect pipeline
print("Pipeline steps:", getattr(pipeline, "named_steps", "no named_steps"))
print("Pipeline classes:", pipeline.classes_)

# Get preprocessor and text transformer
pre = pipeline.named_steps.get("preprocessor", None)
if pre is None:
    print("No preprocessor found in pipeline — cannot inspect TF-IDF.")
    sys.exit(0)

# ColumnTransformer internals
print("\nPreprocessor details:")
print(pre)

# Attempt to locate the text transformer
text_transformer = None
text_column = None
try:
    # ColumnTransformer has attribute .transformers_
    for name, trans, cols in pre.transformers_:
        if trans is None:
            continue
        # Heuristics: TfidfVectorizer has 'vocabulary_' or 'get_feature_names_out'
        if hasattr(trans, "get_feature_names_out") or trans.__class__.__name__.lower().startswith("tfidf"):
            text_transformer = trans
            text_column = cols
            print(f"Found text transformer '{name}', text column: {cols}")
            break
except Exception as e:
    print("Could not iterate transformers_:", e)

if text_transformer is None:
    # fallback: try named_transformers_ if pre has it
    try:
        nt = pre.named_transformers_
        for k, v in nt.items():
            if hasattr(v, "get_feature_names_out"):
                text_transformer = v
                text_column = k
                print("Found text transformer in named_transformers_ as:", k)
                break
    except Exception as e:
        pass

if text_transformer is None:
    print("Text transformer not found. The pipeline might wrap TF-IDF differently.")
else:
    # transform the TEXT column only
    txt = df_features["TEXT"].astype(str).tolist()
    try:
        X_text = text_transformer.transform(txt)
    except Exception as e:
        print("text_transformer.transform failed:", e)
        # If transformer is inside a pipeline expecting a raw column name, attempt to build a small DataFrame
        try:
            X_text = text_transformer.transform(txt)
        except Exception as ex:
            X_text = None

    if X_text is not None:
        # get feature names and non-zero tokens
        try:
            names = text_transformer.get_feature_names_out()
        except:
            try:
                names = text_transformer.vocabulary_.keys()
            except:
                names = None

        print("\nTF-IDF vector shape:", getattr(X_text, "shape", str(type(X_text))))
        if names is not None:
            # convert to dense row
            row = X_text.toarray()[0] if hasattr(X_text, "toarray") else np.array(X_text)[0]
            nz_idx = np.where(row > 0)[0]
            print("Nonzero TF-IDF token counts:", len(nz_idx))
            # show up to 40 tokens with weight
            for i in nz_idx[:40]:
                token = names[i] if hasattr(names, "__getitem__") else list(names)[i]
                print(f"  {token} -> {row[i]:.4f}")
        else:
            print("Could not obtain TF-IDF feature names.")
    else:
        print("Could not compute TF-IDF vector for the TEXT column.")

# Final: pipeline predict_proba on full dataframe
try:
    probs = pipeline.predict_proba(df_features)[0]
    pred = pipeline.predict(df_features)[0]
    print("\nPREDICTION:", pred)
    print("PROBABILITIES:", probs)
    if 1 in list(pipeline.classes_):
        print("Phishing probability (class==1):", probs[list(pipeline.classes_).index(1)])
except Exception as e:
    print("pipeline predict failed:", e)
