import pandas as pd
df = pd.read_csv("data/raw/Phishing_Legitimate_full.csv")
print(df.columns)